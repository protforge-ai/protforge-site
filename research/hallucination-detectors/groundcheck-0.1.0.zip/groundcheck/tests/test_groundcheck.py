import json

from groundcheck.cli import main
from groundcheck.detectors import Lexical, Numeric
from groundcheck.text import content_tokens, numbers, split_sentences


def test_number_normalisation():
    assert numbers("1,000 and 1000 and 1k and 1.0k") == ["1000"] * 4
    assert numbers("grew 12.50% in 3rd place") == ["12.5", "3"]
    assert numbers("2.5m units") == ["2500000"]


def test_content_tokens_drop_stopwords_keep_numbers():
    assert content_tokens("The price is $1,200, and it's cheap!") == ["price", "1200", "cheap"]


def test_split_sentences():
    assert split_sentences("It rose 5%. Then it fell.\nDone here") == ["It rose 5%.", "Then it fell.", "Done here"]


def test_lexical_and_numeric_scores():
    source = "The company earned 1,000 dollars in 2020."
    assert Numeric().score(source, "It earned 1k in 2020.") == 0.0
    assert Numeric().score(source, "It earned 5k in 2020.") == 0.5
    assert Numeric().score(source, "It earned money.") == 0.0
    assert Lexical().score(source, "The company earned 1000 dollars.") == 0.0
    assert Lexical().score(source, "The company lost 900 euros.") > 0.5


def test_cli_score_toy_pair(tmp_path, capsys):
    (tmp_path / "s.txt").write_text("The company earned 1,000 dollars in 2020.", encoding="utf8")
    (tmp_path / "r.txt").write_text("The company earned 1000 dollars. It hired 50 people.", encoding="utf8")
    main(["score", "--source", str(tmp_path / "s.txt"), "--response", str(tmp_path / "r.txt"), "--detector", "numeric"])
    out = json.loads(capsys.readouterr().out)
    assert [s["verdict"] for s in out["sentences"]] == ["supported", "unsupported"]
    assert out["response_score"] == 0.5
