# groundcheck

Cheap hallucination detectors for retrieval-augmented generation (RAG), benchmarked on the public
[RAGTruth](https://github.com/ParticleMedia/RAGTruth) corpus. Built by ProtForge.

Given a source text and a model response, each detector returns a score in [0, 1] (higher = more likely
hallucinated):

| detector | idea | cost |
|---|---|---|
| `lexical` | share of content tokens in the response (lowercased, stopwords and punctuation removed, numbers kept) that never appear in the source | microseconds |
| `numeric` | share of numbers in the response not found in the source after normalising `1,000` / `1000` / `1k`; 0 when the response has no numbers | microseconds |
| `nli` | SummaC-style. Response split into sentences (first 12 scored; later ones fall back to the lexical per-sentence score); source split into sentences; for each response sentence, NLI (`cross-encoder/nli-deberta-v3-small`) against each of the top-3 source sentences by content-token overlap and against their concatenation (each premise capped at 200 tokens); sentence entailment = max over those 4 pairs; score = 1 - the weakest sentence's entailment | about 7 s per response on a loaded 4-thread CPU |
| `llm_judge` | prompt + Anthropic Messages API client (`groundcheck.detectors.LLMJudge`). **Not evaluated** in this benchmark | API cost |
| `ensemble` | logistic regression on the `lexical`, `nli` and `numeric` scores, fit on the train sample only | - |

## Install

```bash
pip install -e .          # numpy, pandas, scikit-learn, torch, transformers
pip install -e ".[test]"  # adds pytest
```

## CLI

```bash
groundcheck score --source source.txt --response response.txt --detector nli
```

Prints JSON with the response score and a per-sentence verdict (`--threshold`, default 0.5, is not tuned;
tune it on your own data). `--detector` is one of `lexical`, `numeric`, `nli`.

```bash
groundcheck bench [--data-dir data] [--out-dir results] [--seed 0] [--train-n 300] [--test-n 900] [--threads 4]
```

Downloads `response.jsonl` and `source_info.jsonl` from the RAGTruth repository into `data/`, scores a
stratified train sample (by task type x label, default 300) and a stratified test subsample (task type x model, default 900 of the 2,700 test responses), tunes each detector's threshold to maximise
F1 on the train sample, and writes to `results/`: `metrics.json`, `by_task.csv`, `by_model.csv`,
`test_scores.csv` (ids and scores only, no source text) and `examples.json`. NLI results are cached in
`data/nli_cache.jsonl`, so an interrupted run resumes. If the NLI speed measured on the train sample projects the
test run past 2.5 hours, the test subsample drops to 600 and `metrics.json` records it (not triggered in the
published run). `lexical` and `numeric` are also scored on the full 2,700-response test split for reference. A CUDA device is used automatically when available.

## Reproduce

```bash
pip install -e ".[test]"
python -m pytest
groundcheck bench --seed 0
```

## Data, license, citation

RAGTruth is released by Particle Media under the MIT License (Copyright (c) 2023 Particle Media; text in the
repository's `LICENSE`). Only per-response scores, ids and short snippets are published here, not the corpus.

> Cheng Niu, Yuanhao Wu, Juno Zhu, Siliang Xu, Kashun Shum, Randy Zhong, Juntong Song, Tong Zhang.
> *RAGTruth: A Hallucination Corpus for Developing Trustworthy Retrieval-Augmented Language Models.*
> ACL 2024. arXiv:2401.00396.

Label: a response is hallucinated if it has at least one annotated span. Split: the corpus's own `train` /
`test` field.

## Results

Run: seed 0, threshold and ensemble fit on a stratified train sample of 299 responses, evaluation on a
stratified test subsample of **900 of the 2,700** test responses (300 per task, stratified by task type x
model). Hallucination base rate in the subsample is 35.3% (35.0% on the full test split). Thresholds maximise F1
on the train sample. 95% intervals are bootstrap intervals over the 900 responses. Total runtime 2 h 33 min
(NLI scoring of 299 + 900 responses, 4 CPU threads, machine shared with other workloads).

| detector | AUROC (95% CI) | precision | recall | F1 |
|---|---|---|---|---|
| `lexical` | 0.778 (0.746-0.806) | 0.476 | 0.858 | 0.612 |
| `nli` | 0.716 (0.681-0.747) | 0.476 | 0.836 | 0.607 |
| `numeric` | 0.535 (0.503-0.566) | 0.353 | 1.000 | 0.522 |
| `ensemble` (LR on the three scores) | 0.766 (0.737-0.797) | 0.450 | 0.934 | 0.607 |
| `llm_judge` | not evaluated | - | - | - |

Predicting "hallucinated" for everything gives precision 0.353, recall 1.0, F1 0.522, so F1 near 0.6 is a modest
gain; AUROC is the better yardstick. `numeric`'s F1-optimal train threshold is 0.0 (flag any response with a
number-like token that is missing from the source), so its precision/recall row is the all-positive baseline.

`lexical` and `numeric` on the full 2,700-response test split (same thresholds), for comparison with the
subsample: `lexical` AUROC 0.785, P 0.477, R 0.876, F1 0.617; `numeric` AUROC 0.551, P 0.349, R 1.000, F1 0.518.

By task type (test subsample, AUROC / F1; base rate in brackets):

| task | n | base rate | lexical | nli | numeric | ensemble |
|---|---|---|---|---|---|---|
| QA | 300 | 0.20 | 0.708 / 0.426 | 0.706 / 0.424 | 0.683 / 0.333 | 0.740 / 0.468 |
| Summary | 300 | 0.20 | 0.616 / 0.332 | 0.627 / 0.360 | 0.478 / 0.333 | 0.582 / 0.361 |
| Data2txt | 300 | 0.66 | 0.661 / 0.797 | 0.496 / 0.784 | 0.514 / 0.795 | 0.663 / 0.795 |

Full test split, `lexical` / `numeric` AUROC: QA 0.713 / 0.658, Summary 0.673 / 0.545, Data2txt 0.697 / 0.526.

Reading the numbers honestly:

- A bag-of-tokens overlap score beats the small NLI model on this corpus, and the logistic-regression ensemble
  (fit on 299 responses) is not better than `lexical` alone overall. The ensemble does best on QA only.
- `nli` is at chance on Data2txt (AUROC 0.50): the source there is flattened JSON and sentence-level NLI against
  key-value lines is a poor fit. It is competitive with `lexical` on QA and Summary.
- `nli` probabilities are saturated near 0 and 1 (the tuned threshold is 0.999), so precision/recall trade off
  sharply around that value.
- Per-model breakdowns are in `results/by_model.csv`, per-response scores in `results/test_scores.csv`, and three
  illustrative cases (two where `nli` catches a hallucination `lexical` misses, one the reverse) in
  `results/examples.json`.

## Limitations

- English only; RAGTruth covers three tasks (QA, summarisation, data-to-text) and a fixed set of generator
  models from 2023. Scores will not transfer to other domains or newer models without re-tuning.
- Labels are response-level (any annotated span). The detectors, especially `nli`, work per sentence, and
  span-level quality is not measured.
- Thresholds are tuned on a train sample of 300 responses to maximise F1, and the ensemble is fit on
  the same sample; both are small.
- NLI on CPU is slow, so the NLI comparison uses a 900-response stratified test subsample and a 299-response
  train sample; confidence intervals on AUROC are bootstrap intervals over that sample. `nli` scores only the
  top-3 retrieved source sentences per response sentence (not the whole source) and the first 12 response
  sentences; later sentences use the lexical score.
- `lexical` and `numeric` use exact token matching with no stemming, number words or unit conversion.
  Structured (JSON) sources in the data-to-text task are flattened into `key: value` lines before scoring.
- `llm_judge` is an interface and prompt only and has not been run.
