import re

STOPWORDS = frozenset(
    """a about above after again against all also am an and any are aren't as at be because been before being
    below between both but by can can't cannot could couldn't did didn't do does doesn't doing don't down during
    each few for from further had hadn't has hasn't have haven't having he he'd he'll he's her here here's hers
    herself him himself his how how's i i'd i'll i'm i've if in into is isn't it it's its itself let's me more
    most mustn't my myself no nor not of off on once only or other ought our ours ourselves out over own same
    shan't she she'd she'll she's should shouldn't so some such than that that's the their theirs them themselves
    then there there's these they they'd they'll they're they've this those through to too under until up very
    was wasn't we we'd we'll we're we've were weren't what what's when when's where where's which while who who's
    whom why why's will with won't would wouldn't you you'd you'll you're you've your yours yourself yourselves
    s t d ll re ve m may might must shall just one""".split()
)

_NUMBER = r"\d+(?:,\d{3})*(?:\.\d+)?|\d*\.\d+"
_TOKEN = re.compile(rf"(?P<num>{_NUMBER})(?P<suf>[kmb]\b|(?:st|nd|rd|th)\b|%)?|(?P<word>[a-z]+(?:'[a-z]+)?)")
_SENT_SPLIT = re.compile(r"(?<=[.!?])[\"')\]]*\s+(?=[\"'(\[]?[A-Z0-9])|\n+")
_CAMEL = re.compile(r"(?<=[a-z])(?=[A-Z])")
_MULT = {"k": 1e3, "m": 1e6, "b": 1e9}


def _canon(num, suffix):
    value = float(num.replace(",", ""))
    if suffix in _MULT:
        value *= _MULT[suffix]
    return f"{value:.10g}"


def numbers(text):
    out = []
    for m in _TOKEN.finditer(text.lower()):
        if m.group("num"):
            out.append(_canon(m.group("num"), m.group("suf")))
    return out


def content_tokens(text):
    out = []
    for m in _TOKEN.finditer(text.lower()):
        if m.group("num"):
            out.append(_canon(m.group("num"), m.group("suf")))
        elif m.group("word") not in STOPWORDS:
            out.append(m.group("word"))
    return out


def split_sentences(text):
    parts = (p.strip() for p in _SENT_SPLIT.split(text))
    return [p for p in parts if sum(c.isalnum() for c in p) >= 3]


def flatten_source(info):
    if isinstance(info, str):
        return info
    lines = []

    def walk(key, value):
        if isinstance(value, dict):
            for k, v in value.items():
                walk(k, v)
        elif isinstance(value, list):
            for v in value:
                walk(key, v)
        elif value is None or value is False:
            return
        elif value is True:
            lines.append(_CAMEL.sub(" ", key) + ".")
        else:
            label = _CAMEL.sub(" ", key) + ": " if key else ""
            lines.append(f"{label}{value}.")

    walk("", info)
    return "\n".join(lines)


def source_text(record):
    info = record["source_info"]
    if isinstance(info, dict) and set(info) == {"question", "passages"}:
        return f"{info['question']}\n{info['passages']}"
    return flatten_source(info)
