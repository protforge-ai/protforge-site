import argparse
import json
import sys
from pathlib import Path

from groundcheck.text import split_sentences


def _score(args):
    from groundcheck.detectors import NLI, Lexical, Numeric

    source = Path(args.source).read_text(encoding="utf8")
    response = Path(args.response).read_text(encoding="utf8")
    sentences = split_sentences(response)
    detector = {"lexical": Lexical, "numeric": Numeric, "nli": NLI}[args.detector]()
    scores = detector.sentence_scores(source, sentences)
    result = {
        "detector": args.detector,
        "threshold": args.threshold,
        "response_score": max(scores, default=0.0) if args.detector == "nli" else detector.score(source, response),
        "sentences": [
            {"text": s, "score": round(v, 4), "verdict": "unsupported" if v >= args.threshold else "supported"}
            for s, v in zip(sentences, scores)
        ],
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))


def _bench(args):
    from groundcheck.bench import run

    run(args)


def main(argv=None):
    parser = argparse.ArgumentParser(prog="groundcheck")
    sub = parser.add_subparsers(dest="command", required=True)

    sc = sub.add_parser("score", help="score a response against a source, per sentence")
    sc.add_argument("--source", required=True)
    sc.add_argument("--response", required=True)
    sc.add_argument("--detector", choices=["lexical", "numeric", "nli"], default="nli")
    sc.add_argument("--threshold", type=float, default=0.5)
    sc.set_defaults(func=_score)

    b = sub.add_parser("bench", help="reproduce the RAGTruth benchmark")
    b.add_argument("--data-dir", default="data")
    b.add_argument("--out-dir", default="results")
    b.add_argument("--seed", type=int, default=0)
    b.add_argument("--threads", type=int, default=4)
    b.add_argument("--train-n", type=int, default=300)
    b.add_argument("--test-n", type=int, default=900, help="stratified test subsample (task x model); falls back to 600 if projected NLI time exceeds 2.5 h")
    b.set_defaults(func=_bench)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    sys.exit(main())
