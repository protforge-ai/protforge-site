import json
import platform
import time
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_recall_curve, precision_recall_fscore_support, roc_auc_score

from groundcheck.detectors import MAX_NLI_SENTENCES, NLI, NLI_MODEL, PREMISE_TOKENS, TOP_K, Lexical, Numeric
from groundcheck.text import source_text, split_sentences

RAW = "https://raw.githubusercontent.com/ParticleMedia/RAGTruth/main"
FILES = {"response.jsonl": "dataset/response.jsonl", "source_info.jsonl": "dataset/source_info.jsonl"}
DETECTORS = ["lexical", "nli", "numeric"]
ENSEMBLE = "ensemble"
SNIPPET = 300
TEST_BUDGET_SECONDS = 2.5 * 3600
TEST_N = 900
FALLBACK_TEST_N = 600


def ensure_data(data_dir):
    data_dir.mkdir(parents=True, exist_ok=True)
    for name, path in FILES.items():
        if not (data_dir / name).exists():
            urllib.request.urlretrieve(f"{RAW}/{path}", data_dir / name)


def load(data_dir):
    def read(name):
        with open(data_dir / name, encoding="utf8") as f:
            return [json.loads(line) for line in f]

    sources = {s["source_id"]: s for s in read("source_info.jsonl")}
    rows = []
    for r in read("response.jsonl"):
        src = sources[r["source_id"]]
        rows.append(
            {
                "id": r["id"],
                "split": r["split"],
                "task_type": src["task_type"],
                "model": r["model"],
                "label": int(len(r["labels"]) > 0),
                "response": r["response"],
                "spans": [x["text"] for x in r["labels"]],
                "label_types": [x["label_type"] for x in r["labels"]],
                "span_pos": [(x["start"], x["end"]) for x in r["labels"]],
                "source": source_text(src),
            }
        )
    return pd.DataFrame(rows)


def stratified(df, keys, n, seed):
    if n is None or n >= len(df):
        return df
    parts = []
    for _, g in df.groupby(keys):
        parts.append(g.sample(n=max(1, round(len(g) * n / len(df))), random_state=seed))
    return pd.concat(parts)


def nli_entailments(df, data_dir, log, threads):
    cache_path = data_dir / "nli_cache.jsonl"
    cache = {}
    if cache_path.exists():
        with open(cache_path, encoding="utf8") as f:
            cache = {k: v for line in f for k, v in json.loads(line).items()}
    todo = df[~df["id"].isin(cache)]
    if len(todo):
        nli = NLI(threads=threads)
        t0 = time.time()
        group = 16
        with open(cache_path, "a", encoding="utf8") as f:
            for i in range(0, len(todo), group):
                part = todo.iloc[i : i + group]
                items = [(r.source, split_sentences(r.response)[:MAX_NLI_SENTENCES]) for r in part.itertuples()]
                for rid, ent in zip(part["id"], nli.entailment(items)):
                    cache[rid] = ent
                    f.write(json.dumps({rid: ent}) + "\n")
                f.flush()
                done = i + len(part)
                log(f"nli {done}/{len(todo)} responses, {time.time() - t0:.0f}s elapsed")
    return [cache[i] for i in df["id"]]


def compute_scores(df, data_dir, log, threads):
    lex, num = Lexical(), Numeric()
    out = df[["id", "split", "task_type", "model", "label"]].copy()
    out["lexical"] = [lex.score(r.source, r.response) for r in df.itertuples()]
    out["numeric"] = [num.score(r.source, r.response) for r in df.itertuples()]
    ents = nli_entailments(df, data_dir, log, threads)
    out["nli"] = [
        max(NLI.sentence_scores_from(r.source, split_sentences(r.response), e), default=0.0)
        for r, e in zip(df.itertuples(), ents)
    ]
    return out


def best_threshold(y, s):
    p, r, t = precision_recall_curve(y, s)
    f1 = 2 * p[:-1] * r[:-1] / np.maximum(p[:-1] + r[:-1], 1e-12)
    return float(t[int(np.argmax(f1))])


def metrics(y, s, thr):
    pred = (s >= thr).astype(int)
    p, r, f, _ = precision_recall_fscore_support(y, pred, average="binary", zero_division=0)
    both = len(set(y)) == 2
    return {
        "n": int(len(y)),
        "base_rate": float(np.mean(y)),
        "auroc": float(roc_auc_score(y, s)) if both else None,
        "precision": float(p),
        "recall": float(r),
        "f1": float(f),
    }


def bootstrap_auroc(y, s, seed, reps=1000):
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(reps):
        i = rng.integers(0, len(y), len(y))
        if len(set(y[i])) == 2:
            vals.append(roc_auc_score(y[i], s[i]))
    return [float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))]


def pick_examples(te, test, thr):
    full = test.set_index("id")
    pos = te[te["label"] == 1].copy()
    pos["gap"] = pos["nli"] - pos["lexical"]
    groups = [
        ("nli_catches_lexical_misses", pos[(pos.nli >= thr["nli"]) & (pos.lexical < thr["lexical"])].sort_values("gap", ascending=False), 2),
        ("lexical_catches_nli_misses", pos[(pos.lexical >= thr["lexical"]) & (pos.nli < thr["nli"])].sort_values("gap"), 1),
    ]
    picks = []
    for kind, sub, want in groups:
        taken = 0
        for row in sub.itertuples():
            rec = full.loc[row.id]
            spans = [(p, t) for p, t in zip(rec["span_pos"], rec["label_types"]) if p[1] - p[0] <= 120]
            if not spans or len(rec["response"]) > 700:
                continue
            (a, b), label_type = spans[0]
            lo = max(0, a - (SNIPPET - (b - a)) // 2)
            picks.append(
                {
                    "kind": kind,
                    "id": row.id,
                    "task_type": row.task_type,
                    "model": row.model,
                    "annotated_span": rec["response"][a:b],
                    "label_type": label_type,
                    "response_snippet": rec["response"][lo : lo + SNIPPET],
                    "scores": {d: round(float(getattr(row, d)), 4) for d in DETECTORS},
                    "thresholds": {d: round(thr[d], 4) for d in DETECTORS},
                }
            )
            taken += 1
            if taken == want:
                break
    return picks[:3]


def run(args):
    t_start = time.time()
    data_dir, out_dir = Path(args.data_dir), Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    def log(msg):
        print(msg, flush=True)

    ensure_data(data_dir)
    df = load(data_dir)
    train = stratified(df[df.split == "train"], ["task_type", "label"], args.train_n, args.seed)
    test_full = df[df.split == "test"]

    t0 = time.time()
    tr = compute_scores(train, data_dir, log, args.threads)
    rate_path = data_dir / "nli_rate.json"
    if not rate_path.exists():
        rate_path.write_text(json.dumps({"seconds_per_response": (time.time() - t0) / len(train)}))
    seconds_per_response = json.loads(rate_path.read_text())["seconds_per_response"]
    test_n = args.test_n
    if seconds_per_response * test_n > TEST_BUDGET_SECONDS:
        test_n = min(test_n, FALLBACK_TEST_N)
    test = stratified(test_full, ["task_type", "model"], test_n, args.seed)
    log(f"train n={len(train)} test n={len(test)} (of {len(test_full)}), {seconds_per_response:.2f}s/response")
    te = compute_scores(test, data_dir, log, args.threads)
    score_seconds = time.time() - t0

    ytr, yte = tr["label"].to_numpy(), te["label"].to_numpy()
    lr = LogisticRegression(random_state=args.seed).fit(tr[DETECTORS], ytr)
    tr[ENSEMBLE] = lr.predict_proba(tr[DETECTORS])[:, 1]
    te[ENSEMBLE] = lr.predict_proba(te[DETECTORS])[:, 1]

    names = DETECTORS + [ENSEMBLE]
    thr = {d: best_threshold(ytr, tr[d].to_numpy()) for d in names}

    result = {
        "overall": {},
        "train_overall": {d: metrics(ytr, tr[d].to_numpy(), thr[d]) for d in names},
    }
    for d in names:
        m = metrics(yte, te[d].to_numpy(), thr[d])
        m["auroc_ci95_bootstrap"] = bootstrap_auroc(yte, te[d].to_numpy(), args.seed)
        m["threshold"] = thr[d]
        result["overall"][d] = m

    def grouped(col):
        rows = []
        for g, sub in te.groupby(col):
            for d in names:
                rows.append({col: g, "detector": d, **metrics(sub["label"].to_numpy(), sub[d].to_numpy(), thr[d])})
        return pd.DataFrame(rows)

    by_task, by_model = grouped("task_type"), grouped("model")
    by_task.to_csv(out_dir / "by_task.csv", index=False)
    by_model.to_csv(out_dir / "by_model.csv", index=False)
    te.drop(columns=["split"]).to_csv(out_dir / "test_scores.csv", index=False)

    full = test_full[["id", "task_type", "model", "label", "source", "response"]]
    lex, num = Lexical(), Numeric()
    ref = full[["id", "task_type", "label"]].copy()
    ref["lexical"] = [lex.score(r.source, r.response) for r in full.itertuples()]
    ref["numeric"] = [num.score(r.source, r.response) for r in full.itertuples()]
    full_ref = {
        "n": len(ref),
        "overall": {d: metrics(ref["label"].to_numpy(), ref[d].to_numpy(), thr[d]) for d in ("lexical", "numeric")},
        "by_task": {
            t: {d: metrics(g["label"].to_numpy(), g[d].to_numpy(), thr[d]) for d in ("lexical", "numeric")}
            for t, g in ref.groupby("task_type")
        },
    }

    examples = pick_examples(te, test, thr)
    (out_dir / "examples.json").write_text(json.dumps(examples, indent=2, ensure_ascii=False), encoding="utf8")

    result.update(
        {
            "full_test_reference_lexical_numeric": full_ref,
            "evaluated_detectors": names,
            "not_evaluated": {"llm_judge": "interface and prompt only; never run"},
            "n_train": len(tr),
            "n_test": len(te),
            "n_test_split_total": len(test_full),
            "test_subsampled": len(te) < len(test_full),
            "test_sampling": "stratified by task_type x model" if len(te) < len(test_full) else "full test split",
            "train_sampling": "stratified by task_type x label",
            "seed": args.seed,
            "models": {"nli": NLI_MODEL},
            "nli_seconds_per_response_measured_on_train": seconds_per_response,
            "nli_method": "SummaC-style: per response sentence, NLI against each of the top-k source sentences by content-token overlap plus their concatenation; max entailment",
            "nli_top_k": TOP_K,
            "nli_premise_max_tokens": PREMISE_TOKENS,
            "nli_max_sentences": MAX_NLI_SENTENCES,
            "nli_overflow_rule": "sentences beyond the cap are scored by the lexical detector's per-sentence score",
            "nli_threads": args.threads,
            "ensemble_coefficients": dict(zip(DETECTORS, map(float, lr.coef_[0])), intercept=float(lr.intercept_[0])),
            "threshold_rule": "maximise F1 on the train sample",
            "label_rule": "hallucinated = at least one annotated span",
            "runtime_seconds": {"scoring_train_and_test": round(score_seconds), "total": round(time.time() - t_start)},
            "platform": platform.platform(),
        }
    )
    (out_dir / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf8")
    log(json.dumps(result["overall"], indent=2))
