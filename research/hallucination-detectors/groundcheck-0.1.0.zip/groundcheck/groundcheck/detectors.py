import json
import os
import urllib.request

import numpy as np

from groundcheck.text import content_tokens, numbers, split_sentences

NLI_MODEL = "cross-encoder/nli-deberta-v3-small"
TOP_K = 3
PREMISE_TOKENS = 200
MAX_NLI_SENTENCES = 12


def _unsupported_share(text, supported, extract):
    items = extract(text)
    if not items:
        return 0.0
    return sum(i not in supported for i in items) / len(items)


class _Overlap:
    extract = None

    def sentence_scores(self, source, sentences):
        supported = set(self.extract(source))
        return [_unsupported_share(s, supported, self.extract) for s in sentences]

    def score(self, source, response):
        return _unsupported_share(response, set(self.extract(source)), self.extract)


class Lexical(_Overlap):
    name = "lexical"
    extract = staticmethod(content_tokens)


class Numeric(_Overlap):
    name = "numeric"
    extract = staticmethod(numbers)


def top_sources(sentence, source_sentences, source_tokens, k=TOP_K):
    wanted = set(content_tokens(sentence))
    ranked = sorted(range(len(source_sentences)), key=lambda i: (-len(wanted & source_tokens[i]), i))
    return sorted(ranked[:k])


class NLI:
    name = "nli"

    def __init__(self, model_id=NLI_MODEL, batch_size=32, threads=4):
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        torch.set_num_threads(threads)
        self.torch = torch
        self.model_id = model_id
        self.batch_size = batch_size
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = AutoModelForSequenceClassification.from_pretrained(model_id).eval().to(self.device)
        labels = {v.lower(): k for k, v in self.model.config.id2label.items()}
        self.entail_idx = labels["entailment"]

    def _clip(self, text):
        enc = self.tokenizer(text, add_special_tokens=False, return_offsets_mapping=True)
        offsets = enc["offset_mapping"]
        return text if len(offsets) <= PREMISE_TOKENS else text[: offsets[PREMISE_TOKENS - 1][1]]

    def entailment(self, items):
        """items: list of (source, sentences); returns, per item, max entailment prob per sentence over its short premises."""
        pairs, owners = [], []
        for i, (source, sentences) in enumerate(items):
            src = split_sentences(source) or [source]
            toks = [set(content_tokens(x)) for x in src]
            for j, sentence in enumerate(sentences):
                top = top_sources(sentence, src, toks)
                premises = {self._clip(src[t]) for t in top}
                premises.add(self._clip(" ".join(src[t] for t in top)))
                for premise in premises:
                    pairs.append((premise, sentence))
                    owners.append((i, j))
        out = [[0.0] * len(s) for _, s in items]
        order = sorted(range(len(pairs)), key=lambda k: len(pairs[k][0]) + len(pairs[k][1]))
        for b in range(0, len(order), self.batch_size):
            idx = order[b : b + self.batch_size]
            enc = self.tokenizer(
                [pairs[k][0] for k in idx],
                [pairs[k][1] for k in idx],
                truncation="only_first",
                max_length=512,
                padding=True,
                return_tensors="pt",
            ).to(self.device)
            with self.torch.inference_mode():
                probs = self.model(**enc).logits.softmax(-1)[:, self.entail_idx].tolist()
            for k, p in zip(idx, probs):
                i, j = owners[k]
                out[i][j] = max(out[i][j], p)
        return out

    @staticmethod
    def sentence_scores_from(source, sentences, entailments):
        overflow = Lexical().sentence_scores(source, sentences[len(entailments) :])
        return [1.0 - e for e in entailments] + overflow

    def sentence_scores(self, source, sentences):
        ent = self.entailment([(source, sentences[:MAX_NLI_SENTENCES])])[0]
        return self.sentence_scores_from(source, sentences, ent)


JUDGE_PROMPT = """You are checking whether an AI-generated response is faithful to a source text.

<source>
{source}
</source>

<response>
{response}
</response>

A response is hallucinated if it contains any claim that contradicts the source or is not supported by the source.
Reply with JSON only: {{"hallucination_probability": <number between 0 and 1>}}"""


class LLMJudge:
    name = "llm_judge"
    url = "https://api.anthropic.com/v1/messages"

    def __init__(self, model):
        self.model = model

    def build_request(self, source, response):
        return {
            "model": self.model,
            "max_tokens": 50,
            "messages": [{"role": "user", "content": JUDGE_PROMPT.format(source=source, response=response)}],
        }

    def score(self, source, response):
        req = urllib.request.Request(
            self.url,
            data=json.dumps(self.build_request(source, response)).encode(),
            headers={
                "x-api-key": os.environ["ANTHROPIC_API_KEY"],
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
        )
        with urllib.request.urlopen(req) as r:
            text = json.load(r)["content"][0]["text"]
        return float(np.clip(json.loads(text)["hallucination_probability"], 0, 1))
